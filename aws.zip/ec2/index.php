

<!DOCTYPE html>
<html>
   <head>
      <title>Aws ec2 Portal</title>
      <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.js"></script>
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/js/bootstrap.min.js"></script>
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twbs-pagination/1.3.1/jquery.twbsPagination.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.5/validator.min.js"></script>
      <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
      <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">
      <script src="index.js"></script>
   </head>
   <body>
      <div class="container">
          <h4>
              <div class="form-inline">
                    <div class="form-group mb-2">
                      <label for="awsEmail">Filter by Aws Account Email</label>
                      <select class="form-control" id="awsEmail" name="awsEmail" >
<?php
    require 'db_config.php';
    $result = $mysqli->query("SELECT * FROM `user`");
    while($row = $result->fetch_assoc()){
        echo '<option value="'.$row[id].'">'.$row[email].'</option>';
    }
?>       
                    </select> 
                    </div>
                    <button type="submit" class="btn btn-primary mb-2 btn-sm apply-filter">Apply Filter</button>
                  </div>
          </h4>
         <div class="row">
            <div class="col-lg-12">                
               <div class="pull-left">
                  <h2>ec2 List</h2>
               </div>
               <div class="pull-right">
                   <a type="button" class="btn btn-warning" href="actions.php">Go to Scheduler/ Bulk Actions</a>
                   <a type="button" class="btn btn-success" href="instance-new.php">Create New Ec2</a>
               </div>
            </div>
         </div>
         <table class="table table-bordered">
            <thead>
               <tr>
                  <th>Instance Id</th>
                  <th>Private Ip</th>
                  <th>Public Ip</th>
                  <th>Instance Type</th>
                  <th>State</th>
                  <th width="200px">Action</th>
               </tr>
            </thead>
            <tbody></tbody>
         </table>
         <ul id="pagination" class="pagination-sm"></ul>
      </div>
   </body>

