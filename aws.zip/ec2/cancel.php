<?php     
require 'db_config.php';
  $uid = $_POST['uid'];
  
  $sql = "DELETE FROM `schedule` "
          . "WHERE `user_id`=".$uid;
  $result = $mysqli->query($sql);
  
  $sql1 = "SELECT * FROM ec2 Order by id desc LIMIT 1"; 
  $result1 = $mysqli->query($sql1);
  $data = $result1->fetch_assoc();
  echo json_encode($data);


?>