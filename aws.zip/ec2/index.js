/* global toastr */

$(document).ready(function() {
    var page = 1;    
    var user = 0;
    var current_page = 1;
    var total_page = 0;
    var is_ajax_fire = 0;
    
    //populate table with data on load
    manageData();


    /* manage data list */
    function manageData() {
        $.ajax({
            dataType: 'json',
            url: 'getData.php',
            data: {
                page: page,
                user : user
            }
        }).done(function(data) {       
            total_page = Math.ceil(data.total / 10);
            current_page = page;

            $('#pagination').twbsPagination({
                totalPages: total_page,
                visiblePages: current_page,
                onPageClick: function(event, pageL) {
                    page = pageL;
                    if (is_ajax_fire !== 0) {                        
                        getPageData();                       
                    }
                }
            });
            //manageRow(data.data);
            getPageData();
            is_ajax_fire = 1;
        });
    }


    /* Get Page Data*/

    function getPageData() {
        $.ajax({
            dataType: 'json',
            url: 'getData.php',
            data: {
                page: page
            }
        }).done(function(data2) {
            manageRow(data2.data);
        });
    }

    /* Add new Item table row */
    function manageRow(data3) {
        var rows = '';
        $.each(data3, function(key, value) {  
            var color = 'black';
            var startDisabled = ''; var stopDisabled = '';  var terminateDisabled = ''; 
            switch(value.state){
                case 'running': color = 'green'; startDisabled='disabled'; break;
                case 'stopped': color = '#FFC300'; stopDisabled='disabled'; break;
                case 'terminated': color = 'red'; startDisabled='disabled'; stopDisabled='disabled'; terminateDisabled='disabled'; break;
                default: break;
            }
            rows = rows + '<tr>';
            rows = rows +  '<td>' + value.instance_id + '</td>';
            rows = rows +  '<td>' + value.private_ip + '</td>';
            rows = rows +  '<td>' + value.elastic_ip + '</td>';
            rows = rows +  '<td>' + value.instance_type + '</td>';
            rows = rows +  '<td style="color : '+color+'">' + value.state + '</td>';
            rows = rows + '<td data-id="'+value.id+'">';
            rows = rows + '<button class="btn btn-success btn-xs start-item" '+startDisabled+'>Start</button> &nbsp';
            rows = rows + '<button class="btn btn-warning btn-xs stop-item" '+stopDisabled+'>Stop</button> &nbsp';
            rows = rows + '<button class="btn btn-danger btn-xs terminate-item" '+terminateDisabled+'>Terminate</button>';
            rows = rows + '</td>';
            rows = rows + '</tr>';
        });

        $("tbody").html(rows);
    }


    $("body").on("click", ".apply-filter", function() {
        var e = document.getElementById("awsEmail");
        user = e.options[e.selectedIndex].value;
        manageData();
    });

    $("body").on("click", ".start-item", function() {
        var id = $(this).parent("td").data('id');
        $.ajax({
            dataType: 'json',
            type: 'POST',
            url: 'start.php',
            data: {
                id: id,
                uid: 1
            }
        }).done(function(data) {       
            toastr.success('Long Operation underway', 'Starting Instance', {
                    timeOut: 25000
                });
                
            setTimeout(function(){ 
                manageData();
                toastr.success('Instance state changed Successfully.', 'Success Alert', {
                timeOut: 5000
            });
            }, 30000);  
        });
    });
    
    $("body").on("click", ".stop-item", function() {
        var id = $(this).parent("td").data('id');
        $.ajax({
            dataType: 'json',
            type: 'POST',
            url: 'stop.php',
            data: {
                id: id,
                uid: 1
            }
        }).done(function(data) {   
            toastr.warning('Long Operation underway', 'Stopping instance', {
                    timeOut: 25000
                });
                
            setTimeout(function(){ 
                manageData();
                toastr.warning('Instance state changed  Successfully.', 'Danger Alert', {
                    timeOut: 5000
                });
            }, 30000);            
        });
    });
    
    $("body").on("click", ".terminate-item", function() {
        var id = $(this).parent("td").data('id');
        $.ajax({
            dataType: 'json',
            type: 'POST',
            url: 'terminate.php',
            data: {
                id: id,
                uid: 1
            }
        }).done(function(data) {      
            toastr.error('Long Operation underway', 'Terminating instance', {
                    timeOut: 25000
                });
                
            setTimeout(function(){ 
                manageData();
                toastr.error('Instance state changed Successfully.', 'Warning Alert', {
                timeOut: 5000
            });
            }, 30000);            
        });
    });

});