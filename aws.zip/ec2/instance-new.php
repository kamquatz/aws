

<!DOCTYPE html>
<html>
   <head>
      <title>Aws ec2 Portal</title>
      <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.js"></script>
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/js/bootstrap.min.js"></script>
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twbs-pagination/1.3.1/jquery.twbsPagination.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.5/validator.min.js"></script>
      <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
      <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">
      <script type="text/javascript">
         //var url = "http://185.141.62.34/projects/freelancer/ec2/";
         var url="http://localhost/freelancer/ec2/"
      </script>
      
   </head>
   <body>
      <div class="container">
         <div class="row">
            <div class="col-lg-6 margin-tb">
               <div class="pull-left">
                  <h2>Enter New ec2 Information</h2>
               </div>
            </div>
         </div>
          <div class="row">
              <div class="col-md-12">
                  <form data-toggle="validator" action="create.php" method="POST">
                      <div class="col-md-6">
                        <div class="form-group">
                           <label class="control-label" for="title">Select Aws Account:</label>
                           <select class="form-control" id="user_id" name="user_id" >
<?php
    require 'db_config.php';
    $result = $mysqli->query("SELECT * FROM `user`");
    while($row = $result->fetch_assoc()){
        echo '<option value="'.$row[id].'">'.$row[email].'</option>';
    }
?>                                </select> 
                           <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                           <label class="control-label" for="title">Ami-id:</label>
                           <select class="form-control" id="ami_id" name="ami_id" >
<?php
    $result0 = $mysqli->query("SELECT * FROM `allowed_ami`");
    while($row = $result0->fetch_assoc()){
        echo '<option value="'.$row[ami_id].'">'.$row[description].'</option>';
    }
?>                          </select> 
                           <div class="help-block with-errors"></div>
                        </div>
                         <div class="form-group">
                           <label class="control-label" for="region">Select Region:</label>
                           <select class="form-control" id="region" name="region" >
<?php
    $result1 = $mysqli->query("SELECT * FROM `allowed_regions`");
    while($row = $result1->fetch_assoc()){
        echo '<option value="'.$row[region].'">'.$row[description].'</option>';
    }
?>
                            </select> 
                           <div class="help-block with-errors"></div>
                        </div>
                      <div class="form-group">
                           <label class="control-label" for="title">Select Instance Type:</label>
                           <select class="form-control" id="instance_type" name="instance_type" >
<?php
    $result2 = $mysqli->query("SELECT * FROM `allowed_instance_types`");
    while($row = $result2->fetch_assoc()){
        echo '<option value="'.$row[instance_type].'">'.$row[description].'</option>';
    }
?>                      </select> 
                           <div class="help-block with-errors"></div>
                        </div>
              </div>
                      <div class="col-md-6">
                         <div class="form-group">
                           <label class="control-label" for="storage">Select Storage:</label>
                           <select class="form-control" id="storage" name="storage" >
<?php
    $result3 = $mysqli->query("SELECT * FROM `allowed_storages`");
    while($row = $result3->fetch_assoc()){
        echo '<option value="'.$row[storage].'">'.$row[description].'</option>';
    }
?>      
                            </select> 
                           <div class="help-block with-errors"></div>
                        </div>
                      <div class="form-group">
                           <label class="control-label" for="security_group">Select Security Group:</label>
                           <select class="form-control" id="security_group" name="security_group" >
<?php
    $result4 = $mysqli->query("SELECT * FROM `security_groups`");
    while($row = $result4->fetch_assoc()){
        echo '<option value="'.$row[security_group].'">'.$row[description].'</option>';
    }
?>      
                            </select><br />
                           <button type="button" class="btn btn-warning btn-xs pull-right" data-toggle="modal" data-target="#new-security-group">
                            or Create New Security Group
                           </button>
                           <div class="help-block with-errors"></div>
                        </div>
                         <div class="form-group">
                           <label class="control-label" for="pwd">SSh password:</label>
                           <input type="password" id="ssh" name="ssh" class="form-control" value="123456" data-error="Please enter password." required />
                           <div class="help-block with-errors"></div>
                        </div>
                         <div class="form-group">
                           <label class="control-label" for="count">No. of instances:</label>
                           <input type="number" name="count" class="form-control" value="1" data-error="Please Enter no. of instances" required />
                           <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                           <button type="submit" class="btn crud-submit btn-success pull-right">Submit Information</button>
                        </div>
                      </div>
                     </form>
              </div>
              
              
         <div class="modal fade" id="new-security-group" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
               <div class="modal-content">
                  <div class="modal-header">
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">X</span></button>
                     <h4 class="modal-title" id="myModalLabel">Edit Item</h4>
                  </div>
                  <div class="modal-body">
                     <form data-toggle="validator" action="create-security-group.php" method="post">
                        <input type="hidden" name="id" class="edit-id">
                        <div class="form-group">
                           <label class="control-label" for="title">Title:</label>
                           <input type="text" name="title" class="form-control" data-error="Please enter title." required />
                           <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                           <label class="control-label" for="title">Description:</label>
                           <textarea name="description" class="form-control" data-error="Please enter description." required></textarea>
                           <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                           <button type="submit" class="btn btn-success crud-submit-edit">Submit</button>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
              
          </div>
      </div>
   </body>

