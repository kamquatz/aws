<?php     
require 'db_config.php';
  $action = $_POST['action'];
  $interval = $_POST['interval'];
  $duration = $_POST['duration'];
  $ids = explode(",",$_POST['ids']);
  $uid = $_POST['uid'];
  
  if($action=='schedule'){
      $laps_remaining = 3600*$duration/$interval;
      foreach ($ids as $id) {
          $sql = "INSERT INTO `schedule`(`instance_id`,`interval`,`duration`,`laps_remaining`,`next`,`user_id`) "
          . "VALUES (".$id.",".$interval.",".$duration.",".$laps_remaining.",NOW(),".$uid.")";
          $result = $mysqli->query($sql);
      } 
  }else{
      foreach ($ids as $id) {
          $sql = "INSERT INTO `method`(`instance_id`,`name`,`user_id`) "
          . "VALUES (".$id.",'".$action."',".$uid.")";
          $result = $mysqli->query($sql);
      } 
  }
  
  $sql1 = "SELECT * FROM ec2 Order by id desc LIMIT 1"; 
  $result1 = $mysqli->query($sql1);
  $data = $result1->fetch_assoc();
  echo json_encode($data);


?>