<?php     
require 'db_config.php';
  $post = $_POST;
  
  $sql = "INSERT INTO `method`(`instance_id`,`name`,`user_id`) "
          . "VALUES (".$post['id'].",'start',".$post['uid'].")";
  $result = $mysqli->query($sql);
  
  $sql = "SELECT * FROM ec2 Order by id desc LIMIT 1"; 
  $result = $mysqli->query($sql);
  $data = $result->fetch_assoc();
  echo json_encode($data);


?>