<?php
define (DB_USER, "script");
define (DB_PASSWORD, "script@123");
define (DB_DATABASE, "aws");
define (DB_HOST, "localhost");
$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
