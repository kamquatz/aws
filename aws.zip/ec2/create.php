
<!DOCTYPE html>
<html>
   <head>
      <title>Aws ec2 Portal</title>
      <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.js"></script>
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/js/bootstrap.min.js"></script>
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twbs-pagination/1.3.1/jquery.twbsPagination.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.5/validator.min.js"></script>
      <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
      <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">
      <script type="text/javascript">
         // var url = "http://185.141.62.34/projects/freelancer/ec2/";
         var url="http://localhost/freelancer/ec2/"
      </script>
   </head>
   <body>
 <?php
   require 'db_config.php';

  $post = $_POST;
    $sql = "INSERT INTO ec2(`image_id`,`region`,`security_group_id`,`instance_type`,`user_id`,`storage`,`count`,`ssh`) "
            . "VALUES ('".$post['ami_id']."','".strtoupper($post['region'])."','".$post['security_group']."','".$post['instance_type']."',".$post['user_id'].",".$post['storage'].",".$post['count'].",'".$post['ssh']."')";
//echo $sql;
    $result = $mysqli->query($sql);
    $ec2Id = $mysqli->insert_id;

    $sql2 = "INSERT INTO `method`(`instance_id`,`name`,`user_id`) "
            . "VALUES(".$ec2Id.",'create',".$post['user_id'].")"; 
    
    $result = $mysqli->query($sql2);
    $methodId = $mysqli->insert_id;

  echo "<script>"
    . "toastr.success('Instance creation request submitted Successfully.', 'Request Id: ".$methodId."', {
                  timeOut: 10000
              });
              
    setTimeout(function(){ 
                    window.location='./';
                }, 4000);     
        
              
        </script>";
  
?>
       
   </body>
</html>