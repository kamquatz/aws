$(document).ready(function() {
    var page = 1;    
    var user = 0;
    var current_page = 1;
    var total_page = 0;
    var is_ajax_fire = 0;
    
    manageData();


    /* manage data list */

    function manageData() {
        $.ajax({
            dataType: 'json',
            url: 'getData.php',
            data: {
                page: page,
                user : user
            }

        }).done(function(data) {       
            total_page = Math.ceil(data.total / 10);
            current_page = page;
            manageRow(data.data);
            is_ajax_fire = 1;
        });


    }


    /* Get Page Data*/

    function getPageData() {
        $.ajax({
            dataType: 'json',
            url: 'getData.php',
            data: {
                page: page
            }
        }).done(function(data2) {
            manageRow(data2.data);
        });
    }

    /* Add new Item table row */

    function manageRow(data3) {
        var rows = '';
        $.each(data3, function(key, value) {
            var color = 'black';
            switch(value.state){
                case 'running': color = 'green'; break;
                case 'stopped': color = '#FFC300'; break;
                case 'terminated': color = 'red'; break;
                default: break;
            }
            rows = rows + '<tr>';
            rows = rows + '<td><input type="checkbox" class="emp_checkbox" data-emp-id="'+value.id+'"></td>';
            rows = rows +  '<td>' + value.instance_id + '</td>';
            rows = rows +  '<td>' + value.private_ip + '</td>';
            rows = rows +  '<td>' + value.elastic_ip + '</td>';
            rows = rows +  '<td>' + value.instance_type + '</td>';
            rows = rows +  '<td style="color : '+color+'">' + value.state + '</td>';
            rows = rows + '</tr>';
        });

        $("tbody").html(rows);
    }

    function perform(action,interval,duration){
        var instances = [];
        $(".emp_checkbox:checked").each(function() {
            instances.push($(this).data('emp-id'));
        });
        if(instances.length <=0) { alert("Please select records."); } 
        else { 
            var selected_values = instances.join(",");
            
            $.ajax({
            dataType: 'json',
            type: 'POST',
            url: 'perform-action.php',
            data: {
                ids: selected_values,
                action: action,
                interval: interval,
                duration: duration,
                uid: 1
            }
        }).done(function(data) {    
            getPageData();
            toastr.success('Requests queued for Processing.', 'Success Alert', {
                    timeOut: 5000
                });
        });
        
        } 
    }
    
    $(document).on('click', '#select_all', function() {
        $(".emp_checkbox").prop("checked", this.checked);
        $("#select_count").html($("input.emp_checkbox:checked").length+" Selected");
    });
    $(document).on('click', '.emp_checkbox', function() {
        if ($('.emp_checkbox:checked').length === $('.emp_checkbox').length) {
            $('#select_all').prop('checked', true);
        } else {
            $('#select_all').prop('checked', false);
        }
        $("#select_count").html($("input.emp_checkbox:checked").length+" Selected");
    });

    
    $("body").on("click", ".apply-filter", function() {
        var e = document.getElementById("awsEmail");
        user = e.options[e.selectedIndex].value;
        manageData();
    });

    $("body").on("click", ".start-selected", function() {
        perform('start');
    });
    
    $("body").on("click", ".stop-selected", function() {
        perform('stop');
    });
    
    $("body").on("click", ".terminate-selected", function() {
        perform('terminate');
    });
    
    
    $("body").on("click", ".schedule-selected", function() {
        perform('schedule',document.getElementById("interval").value,document.getElementById("duration").value);
    });

    
    $("body").on("click", ".schedule-cancel", function() {
        $.ajax({
            dataType: 'json',
            type: 'POST',
            url: 'cancel.php',
            data: {
                uid: 1
            }
        }).done(function(data) {    
            getPageData();
            toastr.success('All scheduled Processes cancelled successfully.', 'Success Alert', {
                    timeOut: 5000
                });
        });
    });
    
    $("body").on("click", ".start-item", function() {
        var id = $(this).parent("td").data('id');
        $.ajax({
            dataType: 'json',
            type: 'POST',
            url: 'start.php',
            data: {
                id: id,
                uid: 1
            }
        }).done(function(data) {       
            toastr.success('Long Operation underway', 'Starting Instance', {
                    timeOut: 25000
                });
                
            setTimeout(function(){ 
                getPageData();
                toastr.success('Instance state changed Successfully.', 'Success Alert', {
                timeOut: 5000
            });
            }, 30000);      
        });
    });

});