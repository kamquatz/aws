-- MySQL dump 10.13  Distrib 5.5.62, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: aws
-- ------------------------------------------------------
-- Server version	5.5.62-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `allowed_ami`
--

DROP TABLE IF EXISTS `allowed_ami`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `allowed_ami` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ami_id` varchar(128) DEFAULT NULL,
  `description` varchar(256) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allowed_ami`
--

LOCK TABLES `allowed_ami` WRITE;
/*!40000 ALTER TABLE `allowed_ami` DISABLE KEYS */;
INSERT INTO `allowed_ami` VALUES (1,'ami-0d8f6eb4f641ef691','Amazon Linux 2 AMI (HVM), SSD Volume Type',NULL,'2019-07-29 16:53:45'),(2,'ami-05c1fa8df71875112','Ubuntu Server 18.04 LTS (HVM), SSD Volume Type',NULL,'2019-07-29 16:53:45'),(3,'ami-4df1c94c','Centos 6 Racemi \"Racemi-CentOS-6-x86_64-HVM',NULL,'2019-07-29 16:53:46');
/*!40000 ALTER TABLE `allowed_ami` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `allowed_instance_types`
--

DROP TABLE IF EXISTS `allowed_instance_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `allowed_instance_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instance_type` varchar(128) DEFAULT NULL,
  `description` varchar(256) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allowed_instance_types`
--

LOCK TABLES `allowed_instance_types` WRITE;
/*!40000 ALTER TABLE `allowed_instance_types` DISABLE KEYS */;
INSERT INTO `allowed_instance_types` VALUES (5,'T2.Nano','T2 Nano',1,'2019-07-29 17:14:40'),(6,'T2.Micro','T2 Micro',1,'2019-07-29 17:14:40'),(7,'T2.Medium','T2 Medium',1,'2019-07-29 17:14:40'),(8,'T2.Large','T2 Large',1,'2019-07-29 17:14:40');
/*!40000 ALTER TABLE `allowed_instance_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `allowed_regions`
--

DROP TABLE IF EXISTS `allowed_regions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `allowed_regions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `region` varchar(32) DEFAULT NULL,
  `description` varchar(64) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allowed_regions`
--

LOCK TABLES `allowed_regions` WRITE;
/*!40000 ALTER TABLE `allowed_regions` DISABLE KEYS */;
INSERT INTO `allowed_regions` VALUES (1,'us_east_2','US East (Ohio)',1,'2019-07-29 16:38:51'),(2,'us_west_1','US West (N. California)',1,'2019-07-29 16:38:51'),(3,'us_west_2','US West (Oregon)',1,'2019-07-29 16:38:51'),(4,'ca_central_1','Canada (Central)',1,'2019-07-29 16:38:51'),(5,'ap_northeast_1','Asia Pacific (Tokyo)',1,'2019-07-29 16:38:51'),(6,'ap_northeast_2','Asia Pacific (Seoul)',1,'2019-07-29 16:38:51'),(7,'ap_south_1','Asia Pacific (Mumbai)',1,'2019-07-29 16:38:51'),(8,'ap_southeast_1','Asia Pacific (Singapore)',1,'2019-07-29 16:38:51'),(9,'ap_southeast_2','Asia Pacific (Sydney)',1,'2019-07-29 16:38:51'),(10,'eu_central_1','EU (Frankfurt)',1,'2019-07-29 16:38:51'),(11,'eu_west_1','EU (Ireland)',1,'2019-07-29 16:38:51'),(12,'eu_west_2','EU (London)',1,'2019-07-29 16:38:51'),(13,'eu_west_3','EU (Paris)',1,'2019-07-29 16:38:51'),(14,'eu_north_1','EU (Stockholm)',1,'2019-07-29 16:38:51');
/*!40000 ALTER TABLE `allowed_regions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `allowed_storages`
--

DROP TABLE IF EXISTS `allowed_storages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `allowed_storages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `storage` varchar(128) DEFAULT NULL,
  `description` varchar(512) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allowed_storages`
--

LOCK TABLES `allowed_storages` WRITE;
/*!40000 ALTER TABLE `allowed_storages` DISABLE KEYS */;
INSERT INTO `allowed_storages` VALUES (1,'8','8 GB',1,'2019-07-29 17:15:08'),(2,'16','16 GB',1,'2019-07-29 17:15:08'),(3,'32','32 GB',1,'2019-07-29 17:15:08'),(4,'64','64 GB',1,'2019-07-29 17:15:08');
/*!40000 ALTER TABLE `allowed_storages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ec2`
--

DROP TABLE IF EXISTS `ec2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ec2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instance_id` varchar(64) DEFAULT NULL,
  `region` varchar(32) NOT NULL DEFAULT 'US_EAST_2',
  `image_id` varchar(64) DEFAULT NULL,
  `private_ip` varchar(64) DEFAULT NULL,
  `security_group_id` varchar(64) DEFAULT NULL,
  `state` varchar(64) DEFAULT NULL,
  `instance_type` varchar(64) DEFAULT NULL,
  `monitoring_state` varchar(64) DEFAULT NULL,
  `elastic_ip` varchar(64) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `storage` int(4) DEFAULT NULL,
  `ssh` varchar(512) DEFAULT NULL,
  `count` int(3) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `instance_id` (`instance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2858 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ec2`
--

LOCK TABLES `ec2` WRITE;
/*!40000 ALTER TABLE `ec2` DISABLE KEYS */;
INSERT INTO `ec2` VALUES (1442,'i-015c4abc1bcf4ff9f','US_EAST_2','ami-05c1fa8df71875112','172.31.40.147','[{GroupName: default,GroupId: sg-150b4875}]','stopped','t2.micro','disabled',NULL,NULL,NULL,NULL,NULL,'2019-08-01 16:19:31'),(2253,'i-000be5e095dde7a02','US_EAST_2','ami-0d8f6eb4f641ef691',NULL,'[]','terminated','t2.medium','disabled',NULL,NULL,NULL,NULL,NULL,'2019-08-01 15:25:02'),(2271,'i-08b5cb24f6594d576','US_EAST_2','ami-0d8f6eb4f641ef691','172.31.45.168','[{GroupName: default,GroupId: sg-150b4875}]','stopped','t2.nano','disabled',NULL,NULL,NULL,NULL,NULL,'2019-08-01 15:25:25'),(2272,'i-072ae8568b9216499','US_EAST_2','ami-0d8f6eb4f641ef691',NULL,'[]','terminated','t2.nano','disabled',NULL,NULL,NULL,NULL,NULL,'2019-08-01 15:25:46'),(2282,'i-01a7b571d754a6ef7','US_EAST_2','ami-0d8f6eb4f641ef691','172.31.40.217','[{GroupName: default,GroupId: sg-150b4875}]','stopped','t2.nano','disabled',NULL,NULL,NULL,NULL,NULL,'2019-08-01 15:26:24'),(2415,'i-00cc70f169319d42d','US_EAST_2','ami-0868c7af9597c3e66',NULL,'[]','terminated','t2.micro','disabled',NULL,NULL,NULL,NULL,NULL,'2019-08-01 16:09:11'),(2488,'i-06206756739704145','US_EAST_2','ami-0d8f6eb4f641ef691','172.31.35.162','[{GroupName: default,GroupId: sg-150b4875}]','stopped','t2.nano','disabled',NULL,NULL,NULL,NULL,NULL,'2019-08-01 16:24:27'),(2489,'i-0a1b3fd838b2e1da8','US_EAST_2','ami-0d8f6eb4f641ef691','172.31.43.12','[{GroupName: default,GroupId: sg-150b4875}]','stopped','t2.nano','disabled',NULL,NULL,NULL,NULL,NULL,'2019-08-01 16:24:37'),(2490,'i-08595e6f6e5f80ec8','US_EAST_2','ami-0d8f6eb4f641ef691','172.31.34.52','[{GroupName: default,GroupId: sg-150b4875}]','stopped','t2.nano','disabled',NULL,NULL,NULL,NULL,NULL,'2019-08-01 16:24:23'),(2491,'i-08ec0a6e11b695ef0','US_EAST_2','ami-0d8f6eb4f641ef691','172.31.43.214','[{GroupName: default,GroupId: sg-150b4875}]','stopped','t2.nano','disabled',NULL,NULL,NULL,NULL,NULL,'2019-08-01 16:24:19'),(2504,'i-02148f387d9ebac6c','US_EAST_2','ami-0d8f6eb4f641ef691','172.31.37.170','[{GroupName: default,GroupId: sg-150b4875}]','running','t2.nano','disabled','3.16.45.68',NULL,NULL,NULL,NULL,'2019-08-01 15:50:11'),(2577,'i-094c890a00ac1990c','US_EAST_2','ami-0868c7af9597c3e66','172.31.9.220','[{GroupName: awseb-e-gsy9charzs-stack-AWSEBSecurityGroup-11SSCEK','running','t2.micro','disabled','52.14.147.97',NULL,NULL,NULL,NULL,'2019-08-01 16:09:11');
/*!40000 ALTER TABLE `ec2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `method`
--

DROP TABLE IF EXISTS `method`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `method` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instance_id` varchar(64) DEFAULT NULL,
  `name` varchar(64) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `picked` int(1) DEFAULT '0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `method`
--

LOCK TABLES `method` WRITE;
/*!40000 ALTER TABLE `method` DISABLE KEYS */;
INSERT INTO `method` VALUES (131,'2253','stop',1,1,'2019-08-01 15:09:34'),(132,'2253','stop',1,1,'2019-08-01 15:14:54'),(133,'2272','stop',1,1,'2019-08-01 15:23:53'),(134,'2253','terminate',1,1,'2019-08-01 15:25:01'),(135,'2272','terminate',1,1,'2019-08-01 15:25:45'),(136,'2271','stop',1,1,'2019-08-01 15:25:24'),(137,'2282','stop',1,1,'2019-08-01 15:26:23'),(138,'2253','stop',1,1,'2019-08-01 15:43:39'),(139,'2482','create',1,1,'2019-08-01 15:48:00'),(140,'2493','create',1,1,'2019-08-01 15:50:09');
/*!40000 ALTER TABLE `method` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instance_id` int(11) NOT NULL,
  `interval` int(11) NOT NULL,
  `duration` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `laps_remaining` int(11) DEFAULT '0',
  `next` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
INSERT INTO `schedule` VALUES (34,2490,5,1,1,715,'2019-08-01 19:29:19','2019-08-01 16:24:19'),(35,2488,5,1,1,715,'2019-08-01 19:29:22','2019-08-01 16:24:22'),(36,2415,5,1,1,715,'2019-08-01 19:29:26','2019-08-01 16:24:26'),(37,1442,5,1,1,715,'2019-08-01 19:29:29','2019-08-01 16:24:29'),(38,2489,5,1,1,715,'2019-08-01 19:29:33','2019-08-01 16:24:33'),(39,2491,5,1,1,715,'2019-08-01 19:29:36','2019-08-01 16:24:36');
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_groups`
--

DROP TABLE IF EXISTS `security_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `security_group` varchar(128) DEFAULT NULL,
  `description` varchar(512) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_groups`
--

LOCK TABLES `security_groups` WRITE;
/*!40000 ALTER TABLE `security_groups` DISABLE KEYS */;
INSERT INTO `security_groups` VALUES (1,'default','Default',1,'2019-07-29 17:15:19');
/*!40000 ALTER TABLE `security_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(64) NOT NULL,
  `secret` varchar(128) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `pwd` varchar(512) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `key_pair` (`key`,`secret`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'AKIAUSJ2XUA5U4OOCUP7','qU1RJXvQtDJeZg7SjFT9dWSfFMOWxe/z6wgJfg8z','dennismuga22@gmail.com','e383aae90bcf11a44d6e5e467b4012ba0531ceb551f6d9331367c5c1e134885af8595e80466d553d8a735a809db52a731857990ebbaaaa38f9f8a3b74c2970ae','2019-07-29 17:14:02');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-01 19:29:13
