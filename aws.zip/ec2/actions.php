

<!DOCTYPE html>
<html>
   <head>
      <title>Aws ec2 Portal</title>
      <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.js"></script>
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/js/bootstrap.min.js"></script>
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twbs-pagination/1.3.1/jquery.twbsPagination.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.5/validator.min.js"></script>
      <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
      <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">
      <script src="actions.js"></script>
   </head>
   <body>
      <div class="container">
          <h4>
              <div class="form-inline">
                    <div class="form-group mb-2">
                      <label for="awsEmail">Filter by Aws Account Email</label>
                      <select class="form-control" id="awsEmail" name="awsEmail" >
<?php
    require 'db_config.php';
    $result = $mysqli->query("SELECT * FROM `user`");
    while($row = $result->fetch_assoc()){
        echo '<option value="'.$row[id].'">'.$row[email].'</option>';
    }
?>       
                    </select> 
                    </div>
                    <button type="submit" class="btn btn-primary mb-2 btn-sm apply-filter">Apply Filter</button>
                  </div>
          </h4>
         <div class="row">
            <div class="col-lg-12">                
               <div class="pull-left">
                  <h2>ec2 Actions List</h2>
               </div>
               <div class="pull-right">
                   <a type="button" class="btn btn-success" href="instance-new.php">
                  Create New Ec2
                  </a>
               </div>
            </div>
         </div>
          <div class="form-inline">
            <div class="form-group mb-2 small">                      
                <button type="submit" class="btn btn-success mb-2 btn-sm start-selected">Start Selected</button>
                <button type="submit" class="btn btn-warning mb-2 btn-sm stop-selected">Stop Selected</button>
                <button type="submit" class="btn btn-danger mb-2 btn-sm terminate-selected">Terminate Selected</button>
                <label for="awsEmail">Schedule Start Stop @ </label>
                <input type="number" id="interval" name="interval" class="form-control form-control-sm" value="1" />
                 <label for="awsEmail">Mins Interval; For </label>
                 <input type="number" id="duration" name="duration" class="form-control form-control-sm" value="1"/>
                 <label for="awsEmail">Hrs </label>
                <button type="submit" class="btn btn-primary mb-2 btn-sm schedule-selected">Apply Schedule</button>
                <button type="submit" class="btn btn-default mb-2 btn-sm schedule-cancel">Cancel All Scheduled</button>
              </div>
         </div><br />
       
         <table class="table table-bordered">
            <thead>
               <tr>
                  <th><input type="checkbox" id="select_all"></th>
                  <th>Instance Id</th>
                  <th>Private Ip</th>
                  <th>Public Ip</th>
                  <th>Instance Type</th>
                  <th>State</th>
               </tr>
            </thead>
            <tbody></tbody>
         </table>
         <ul id="pagination" class="pagination-sm"></ul>
         
         
   </body>

